$(document).ready(function() {
	// Tabs
	$("#horario").datetimepicker();
});