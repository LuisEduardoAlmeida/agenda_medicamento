$(document).ready(function() {
	jQuery(function() {
		jQuery('.tooltip').tooltip({
			track: true,
			delay: 0,
			showURL: false,
			showBody: " - ",
			fade: 250
			});
		});
	
});