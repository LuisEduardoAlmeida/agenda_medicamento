class Atendente < Usuario
  attr_accessible :turno
end
