class Exame < ActiveRecord::Base
  attr_accessible :descricao, :nome, :preco
end
