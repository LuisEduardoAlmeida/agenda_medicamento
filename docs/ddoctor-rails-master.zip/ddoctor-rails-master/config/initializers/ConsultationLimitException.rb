class ConsultationLimitException < Exception
end
