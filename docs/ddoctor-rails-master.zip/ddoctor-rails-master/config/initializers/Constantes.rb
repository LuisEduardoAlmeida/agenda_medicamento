class Constantes
  SUCESSO = 1
  ERRO = 0
  SEM_RESULTADOS = 3

  MENSAGEM_SUCESSO = "success"
  MENSAGEM_ERRO = "error"
  MENSAGEM_AVISO = "notice"
end