require 'test_helper'

class SalesControllerTest < ActionDispatch::IntegrationTest
end
