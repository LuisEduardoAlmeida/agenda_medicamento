require 'test_helper'

class PresentationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
