require 'test_helper'

class PresentationDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
