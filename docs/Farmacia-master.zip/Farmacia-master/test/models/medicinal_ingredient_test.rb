require 'test_helper'

class MedicinalIngredientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
