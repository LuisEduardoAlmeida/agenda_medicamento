require 'test_helper'

class TransactionDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
