require 'test_helper'

class AggregateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
