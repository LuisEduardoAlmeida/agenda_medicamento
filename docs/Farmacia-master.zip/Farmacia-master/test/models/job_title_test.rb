require 'test_helper'

class JobTitleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
