class Checkout < ApplicationRecord
end
