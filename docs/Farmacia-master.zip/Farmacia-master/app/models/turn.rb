class Turn < ApplicationRecord
end
