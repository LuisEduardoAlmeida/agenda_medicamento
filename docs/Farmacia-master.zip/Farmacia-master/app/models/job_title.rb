class JobTitle < ApplicationRecord
end
