class Aggregate < ApplicationRecord
end
