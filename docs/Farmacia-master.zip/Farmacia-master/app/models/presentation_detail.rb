class PresentationDetail < ApplicationRecord
  belongs_to :presentation
  belongs_to :product
end
