class HistoricPrice < ApplicationRecord
    belongs_to :product
end
