class Quotation < ApplicationRecord
  belongs_to :checkout
end
