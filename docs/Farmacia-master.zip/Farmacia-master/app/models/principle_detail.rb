class PrincipleDetail < ApplicationRecord
  belongs_to :product
  belongs_to :principle
end
