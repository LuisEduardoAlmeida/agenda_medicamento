module RutHelper
end
