module LowStockHelper
end
