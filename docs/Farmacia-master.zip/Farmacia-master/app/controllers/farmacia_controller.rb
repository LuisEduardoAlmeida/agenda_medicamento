class FarmaciaController < ApplicationController
  def index
  end
end
